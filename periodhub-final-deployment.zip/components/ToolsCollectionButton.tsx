// This component has been removed as downloads page is no longer needed
// All PDF downloads are now handled through the articles page
